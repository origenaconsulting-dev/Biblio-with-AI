# HIV Literature Digest

A local web app that searches PubMed weekly for papers on long-acting antiretrovirals
(LA-ARV, injectable and oral) and broadly neutralising antibodies (bnAbs) for HIV
treatment — Phase 1, 2 and 3 — and sends a curated digest to your inbox via Gmail.

---

## Setup (one time)

1. Make sure Node.js is installed (https://nodejs.org).

2. Open a terminal in this folder and run:

       npm install

3. Get an Anthropic API key at https://console.anthropic.com
   (free to create; you are charged only for usage — a weekly digest costs a few cents).

---

## Running the app

In a terminal, from this folder:

    npm start

Then open http://localhost:3000 in your browser.

---

## Using the app

1. Enter your recipient email address.
2. Paste your Anthropic API key.
3. Adjust the search window and queries if needed.
4. Click "Run digest".
5. Review the preview, then click "Send via Gmail" or "Copy text".

---

## Stopping the server

Press Ctrl+C in the terminal.
