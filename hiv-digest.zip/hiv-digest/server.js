/**
 * HIV Literature Digest — local proxy server
 * Run: node server.js   →   open http://localhost:3000
 */

const express  = require('express');
const path     = require('path');
const nodemailer = require('nodemailer');
const { getJournalMetrics, JOURNAL_METRICS } = require('./journals');

const app  = express();
const PORT = 3000;

app.use(express.json({ limit: '4mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── Proxy → Anthropic API
app.post('/api/anthropic', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || !apiKey.startsWith('sk-ant')) {
    return res.status(401).json({ error: 'Missing or invalid API key.' });
  }
  try {
    const { default: fetch } = await import('node-fetch');
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(req.body)
    });
    const data = await upstream.json();
    res.status(upstream.status).json(data);
  } catch (err) {
    console.error('Anthropic proxy error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Return full journal metrics store (for client-side caching)
app.get('/api/journal-metrics-all', (req, res) => {
  const result = {};
  for (const [k, v] of Object.entries(JOURNAL_METRICS)) result[k] = v;
  res.json(result);
});

// ── Receive merged metrics from CSV import, update in-memory store
app.post('/api/journal-metrics-update', (req, res) => {
  const updates = req.body;
  if (typeof updates !== 'object') return res.status(400).json({ error: 'Expected object' });
  let count = 0;
  for (const [name, metrics] of Object.entries(updates)) {
    JOURNAL_METRICS[name.toLowerCase().trim()] = metrics;
    count++;
  }
  console.log(`Journal metrics updated: ${count} entries`);
  res.json({ ok: true, count });
});

// ── Journal metrics lookup
app.post('/api/journal-metrics', (req, res) => {
  const { journals } = req.body;
  if (!Array.isArray(journals)) return res.status(400).json({ error: 'Expected { journals: string[] }' });
  const result = {};
  for (const name of journals) result[name] = getJournalMetrics(name);
  res.json(result);
});

// ── Send email via SMTP (Gmail App Password)
// Body: { gmailUser, gmailAppPassword, to, subject, text }
app.post('/api/send-email', async (req, res) => {
  const { gmailUser, gmailAppPassword, to, subject, text } = req.body;
  if (!gmailUser || !gmailAppPassword || !to || !subject || !text) {
    return res.status(400).json({ error: 'Missing required fields: gmailUser, gmailAppPassword, to, subject, text.' });
  }
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: gmailUser, pass: gmailAppPassword }
    });
    await transporter.sendMail({
      from: `"HIV Digest" <${gmailUser}>`,
      to,
      subject,
      text,
    });
    res.json({ ok: true });
  } catch (err) {
    console.error('Email send error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`\n✓ HIV Digest server running`);
  console.log(`  Open http://localhost:${PORT} in your browser\n`);
});
