/**
 * Journal metrics lookup table
 * JIF: Clarivate JCR 2023 | CiteScore: Scopus 2023 | SJR: SCImago 2023
 * Tier (JIF-based): Q1 ≥ 10 | Q2 5–9.99 | Q3 2–4.99 | Q4 < 2
 */
const JOURNAL_METRICS = {
  "new england journal of medicine":          { jif: 96.2,  citeScore: 106.0, sjr: 29.1,  sjrQ: "Q1", tier: "Q1" },
  "the lancet":                               { jif: 98.4,  citeScore: 102.0, sjr: 28.4,  sjrQ: "Q1", tier: "Q1" },
  "jama":                                     { jif: 63.1,  citeScore: 72.0,  sjr: 18.9,  sjrQ: "Q1", tier: "Q1" },
  "the bmj":                                  { jif: 39.9,  citeScore: 44.0,  sjr: 10.5,  sjrQ: "Q1", tier: "Q1" },
  "bmj":                                      { jif: 39.9,  citeScore: 44.0,  sjr: 10.5,  sjrQ: "Q1", tier: "Q1" },
  "nature medicine":                          { jif: 58.7,  citeScore: 60.0,  sjr: 18.2,  sjrQ: "Q1", tier: "Q1" },
  "nature":                                   { jif: 64.8,  citeScore: 76.0,  sjr: 20.3,  sjrQ: "Q1", tier: "Q1" },
  "science":                                  { jif: 56.9,  citeScore: 65.0,  sjr: 17.8,  sjrQ: "Q1", tier: "Q1" },
  "cell":                                     { jif: 45.5,  citeScore: 50.0,  sjr: 15.1,  sjrQ: "Q1", tier: "Q1" },
  "annals of internal medicine":              { jif: 19.6,  citeScore: 24.0,  sjr: 6.4,   sjrQ: "Q1", tier: "Q1" },
  "lancet infectious diseases":               { jif: 36.4,  citeScore: 40.0,  sjr: 10.8,  sjrQ: "Q1", tier: "Q1" },
  "the lancet infectious diseases":           { jif: 36.4,  citeScore: 40.0,  sjr: 10.8,  sjrQ: "Q1", tier: "Q1" },
  "lancet hiv":                               { jif: 17.6,  citeScore: 20.0,  sjr: 5.2,   sjrQ: "Q1", tier: "Q1" },
  "the lancet hiv":                           { jif: 17.6,  citeScore: 20.0,  sjr: 5.2,   sjrQ: "Q1", tier: "Q1" },
  "lancet microbe":                           { jif: 20.9,  citeScore: 18.0,  sjr: 6.1,   sjrQ: "Q1", tier: "Q1" },
  "journal of the international aids society":{ jif: 4.8,   citeScore: 7.2,   sjr: 1.8,   sjrQ: "Q1", tier: "Q2" },
  "aids":                                     { jif: 4.0,   citeScore: 6.1,   sjr: 1.6,   sjrQ: "Q1", tier: "Q2" },
  "hiv medicine":                             { jif: 3.2,   citeScore: 4.8,   sjr: 1.1,   sjrQ: "Q1", tier: "Q3" },
  "journal of acquired immune deficiency syndromes": { jif: 3.1, citeScore: 4.5, sjr: 1.2, sjrQ: "Q1", tier: "Q3" },
  "jaids":                                    { jif: 3.1,   citeScore: 4.5,   sjr: 1.2,   sjrQ: "Q1", tier: "Q3" },
  "aids research and human retroviruses":     { jif: 1.8,   citeScore: 3.1,   sjr: 0.7,   sjrQ: "Q2", tier: "Q4" },
  "aids and behavior":                        { jif: 3.4,   citeScore: 5.0,   sjr: 1.3,   sjrQ: "Q1", tier: "Q3" },
  "current hiv/aids reports":                 { jif: 4.1,   citeScore: 5.9,   sjr: 1.4,   sjrQ: "Q1", tier: "Q2" },
  "aids reviews":                             { jif: 3.5,   citeScore: 5.2,   sjr: 1.2,   sjrQ: "Q1", tier: "Q3" },
  "retrovirology":                            { jif: 4.1,   citeScore: 6.0,   sjr: 1.5,   sjrQ: "Q1", tier: "Q2" },
  "viruses":                                  { jif: 3.8,   citeScore: 5.5,   sjr: 1.0,   sjrQ: "Q1", tier: "Q3" },
  "clinical infectious diseases":             { jif: 11.8,  citeScore: 15.0,  sjr: 3.8,   sjrQ: "Q1", tier: "Q1" },
  "journal of infectious diseases":           { jif: 5.0,   citeScore: 7.5,   sjr: 1.9,   sjrQ: "Q1", tier: "Q2" },
  "the journal of infectious diseases":       { jif: 5.0,   citeScore: 7.5,   sjr: 1.9,   sjrQ: "Q1", tier: "Q2" },
  "open forum infectious diseases":           { jif: 3.8,   citeScore: 5.5,   sjr: 1.1,   sjrQ: "Q1", tier: "Q3" },
  "emerging infectious diseases":             { jif: 7.2,   citeScore: 10.0,  sjr: 2.5,   sjrQ: "Q1", tier: "Q1" },
  "infection":                                { jif: 5.4,   citeScore: 7.8,   sjr: 1.6,   sjrQ: "Q1", tier: "Q2" },
  "international journal of infectious diseases": { jif: 4.9, citeScore: 7.0, sjr: 1.4,   sjrQ: "Q1", tier: "Q2" },
  "antimicrobial agents and chemotherapy":    { jif: 4.9,   citeScore: 7.2,   sjr: 1.7,   sjrQ: "Q1", tier: "Q2" },
  "journal of antimicrobial chemotherapy":    { jif: 5.1,   citeScore: 7.6,   sjr: 1.8,   sjrQ: "Q1", tier: "Q2" },
  "plos pathogens":                           { jif: 5.5,   citeScore: 8.1,   sjr: 2.1,   sjrQ: "Q1", tier: "Q2" },
  "ebiomedicine":                             { jif: 9.7,   citeScore: 12.0,  sjr: 2.9,   sjrQ: "Q1", tier: "Q1" },
  "eclinicalmedicine":                        { jif: 9.6,   citeScore: 11.0,  sjr: 2.8,   sjrQ: "Q1", tier: "Q1" },
  "infectious diseases and therapy":          { jif: 4.8,   citeScore: 6.0,   sjr: 1.3,   sjrQ: "Q1", tier: "Q2" },
  "bmc infectious diseases":                  { jif: 3.4,   citeScore: 5.0,   sjr: 1.0,   sjrQ: "Q1", tier: "Q3" },
  "immunity":                                 { jif: 25.5,  citeScore: 32.0,  sjr: 8.2,   sjrQ: "Q1", tier: "Q1" },
  "journal of experimental medicine":         { jif: 10.3,  citeScore: 13.0,  sjr: 3.5,   sjrQ: "Q1", tier: "Q1" },
  "journal of virology":                      { jif: 4.7,   citeScore: 6.8,   sjr: 1.6,   sjrQ: "Q1", tier: "Q2" },
  "plos medicine":                            { jif: 10.5,  citeScore: 14.0,  sjr: 3.8,   sjrQ: "Q1", tier: "Q1" },
  "plos one":                                 { jif: 3.7,   citeScore: 5.2,   sjr: 0.9,   sjrQ: "Q1", tier: "Q3" },
  "nature immunology":                        { jif: 27.7,  citeScore: 34.0,  sjr: 9.1,   sjrQ: "Q1", tier: "Q1" },
  "cell host & microbe":                      { jif: 20.6,  citeScore: 26.0,  sjr: 7.0,   sjrQ: "Q1", tier: "Q1" },
  "cell host and microbe":                    { jif: 20.6,  citeScore: 26.0,  sjr: 7.0,   sjrQ: "Q1", tier: "Q1" },
  "science translational medicine":           { jif: 15.8,  citeScore: 20.0,  sjr: 5.4,   sjrQ: "Q1", tier: "Q1" },
  "npj vaccines":                             { jif: 9.2,   citeScore: 11.0,  sjr: 2.6,   sjrQ: "Q1", tier: "Q1" },
  "journal of controlled release":            { jif: 10.5,  citeScore: 13.0,  sjr: 2.8,   sjrQ: "Q1", tier: "Q1" },
  "advanced drug delivery reviews":           { jif: 15.6,  citeScore: 20.0,  sjr: 4.5,   sjrQ: "Q1", tier: "Q1" },
  "antimicrobial resistance and infection control": { jif: 5.9, citeScore: 8.0, sjr: 1.7, sjrQ: "Q1", tier: "Q2" },
  "clinical pharmacokinetics":                { jif: 5.6,   citeScore: 7.5,   sjr: 1.6,   sjrQ: "Q1", tier: "Q2" },
  "british journal of clinical pharmacology": { jif: 4.0,   citeScore: 5.8,   sjr: 1.2,   sjrQ: "Q1", tier: "Q2" },
  "clinical pharmacology & therapeutics":     { jif: 6.9,   citeScore: 9.5,   sjr: 2.0,   sjrQ: "Q1", tier: "Q2" },
  "antiviral research":                       { jif: 5.8,   citeScore: 8.4,   sjr: 1.8,   sjrQ: "Q1", tier: "Q2" },
  "antiviral therapy":                        { jif: 1.5,   citeScore: 2.8,   sjr: 0.6,   sjrQ: "Q2", tier: "Q4" },
  "drugs":                                    { jif: 7.4,   citeScore: 10.0,  sjr: 2.1,   sjrQ: "Q1", tier: "Q1" },
  "trials":                                   { jif: 2.9,   citeScore: 4.5,   sjr: 0.9,   sjrQ: "Q1", tier: "Q3" },
  "bmc medicine":                             { jif: 9.3,   citeScore: 12.0,  sjr: 2.7,   sjrQ: "Q1", tier: "Q1" },
  "journal of clinical investigation":        { jif: 13.3,  citeScore: 17.0,  sjr: 4.4,   sjrQ: "Q1", tier: "Q1" },
  "american journal of epidemiology":         { jif: 5.0,   citeScore: 7.0,   sjr: 1.8,   sjrQ: "Q1", tier: "Q2" },
  "epidemiology and infection":               { jif: 3.3,   citeScore: 4.8,   sjr: 1.0,   sjrQ: "Q1", tier: "Q3" },
  "journal of clinical virology":             { jif: 4.6,   citeScore: 6.5,   sjr: 1.4,   sjrQ: "Q1", tier: "Q2" },
  "sexually transmitted infections":          { jif: 3.8,   citeScore: 5.6,   sjr: 1.2,   sjrQ: "Q1", tier: "Q3" },
  "sexually transmitted diseases":            { jif: 3.2,   citeScore: 4.8,   sjr: 1.0,   sjrQ: "Q1", tier: "Q3" },
  "medrxiv":                                  { jif: null,  citeScore: null,  sjr: null,   sjrQ: null,  tier: "Preprint" },
  "biorxiv":                                  { jif: null,  citeScore: null,  sjr: null,   sjrQ: null,  tier: "Preprint" },
};

function getJournalMetrics(journalName) {
  if (!journalName) return null;
  const key = journalName.toLowerCase().trim();
  if (JOURNAL_METRICS[key]) return { ...JOURNAL_METRICS[key], matched: journalName };
  let best = null, bestLen = 0;
  for (const [k, v] of Object.entries(JOURNAL_METRICS)) {
    if (key.includes(k) && k.length > bestLen) {
      best = { ...v, matched: k };
      bestLen = k.length;
    }
  }
  return best;
}

module.exports = { JOURNAL_METRICS, getJournalMetrics };
